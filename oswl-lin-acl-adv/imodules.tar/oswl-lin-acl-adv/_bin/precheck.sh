if [[ $1 == project/* ]];then
    getfacl /home/project/*
fi

